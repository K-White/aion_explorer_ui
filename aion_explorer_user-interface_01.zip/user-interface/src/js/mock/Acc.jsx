const Acc = 
{
  content:[
    {
      balance:3.14154e+23,
      id:1,
      addr:"8f30ce8eb81c57388bc25820b0f8d0612451c9f90091224028b9c562fc9c7036"
    }
  ]
}

export default Acc;

